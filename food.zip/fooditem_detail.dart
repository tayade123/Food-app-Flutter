import 'package:flutter/material.dart';
import 'package:j_130_food/fooditem.dart';

class FoodItemDetail extends StatelessWidget {
  final String foodId;
  const FoodItemDetail({Key? key, required this.foodId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final _fooditem =
        FoodItem.foodItems.firstWhere((element) => element.id == foodId);
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        title:  Text(_fooditem.name),
        backgroundColor: Colors.blue,
        elevation: 8,
        foregroundColor: Colors.black,
      ),

      body: Column(
        children: [
          const SizedBox(
            height: 16,
          ),
          Expanded(
            flex: 3,
            child: PageView.builder(
              itemCount: _fooditem.images.length,
              itemBuilder: (context, index) {
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  child: Image.asset(
                    _fooditem.images[index],
                    fit: BoxFit.fitWidth,
                  ),
                );
              },
            ),
          ),
          const SizedBox(
            height: 16,
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Text(
                      _fooditem.description,
                      style:
                          const TextStyle(color: Colors.black, fontSize: 18),
                    )
                  ],
                ),
              ),
            ),
            flex: 3,
          )
        ],
      ),
    );
  }
}

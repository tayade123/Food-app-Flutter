import 'package:flutter/material.dart';
import 'package:j_130_food/food_item_widget.dart';
import 'package:j_130_food/fooditem.dart';
import 'package:j_130_food/fooditem_detail.dart';

class HomePage extends StatelessWidget {
  HomePage({Key? key}) : super(key: key);
  final _foodItems = FoodItem.foodItems;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("J_147_Food Delivery"),
          backgroundColor: Colors.blue,
      ),
      body: SizedBox(
        // padding: const EdgeInsets.symmetric(horizontal: 16),
        height: double.infinity,
        width: double.infinity,
        child: ListView.builder(
          itemCount: _foodItems.length,
          padding: const EdgeInsets.all(20),
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) {
                    return FoodItemDetail(foodId: _foodItems[index].id);
                  },
                ));
              },
              child: FoodItemWidget(
                  imagePath: _foodItems[index].images[0],
                  name: _foodItems[index].name,
                  price: _foodItems[index].price),
            );
          },
        ),
      ),
    );
  }
}

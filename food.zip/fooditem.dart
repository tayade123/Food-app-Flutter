class FoodItem {
  final String id;
  final String name;
  final List<String> images;
  final double price;
  final String description;

  FoodItem({
    required this.name,
    required this.id,
    required this.images,
    required this.price,
    required this.description,
  });

  static List<FoodItem> foodItems = [
    FoodItem(
      name: "Samosa",
      id: "101",
      images: [
        "assets/images/samosa.jpg",
        "assets/images/samosa1.jpg",
        "assets/images/samosa2.jpg",
        "assets/images/samosa3.jpg"
      ],
      price: 55,
      description:
      "The samosa is prepared with an all-purpose flour (locally known as maida) and stuffed with a filling, often a mixture of diced and cooked or mashed boiled potato (preferably diced), onions, green peas, lentils, ginger, spices and green chili.[18][19] A samosa can be vegetarian or non-vegetarian, depending on the filling. The entire pastry is deep-fried in vegetable oil or rarely ghee to a golden brown. It is served hot, often with fresh green chutney, such as mint, coriander, or tamarind. It can also be prepared in a sweet form. Samosas are often served in chaat, along with the traditional accompaniments of either a chickpea or a white pea preparation, served with yogurt, tamarind paste and green chutney, garnished with chopped onions, coriander, and chaat masala.",
    ),
    FoodItem(
      name: "Vadapav",
      id: "102",
      images: [
        "assets/images/vadapav.jpg",
        "assets/images/vadapv1.jpg",
        "assets/images/vadapav2.jpg",
        "assets/images/vadapav3.jpg"
      ],
      price: 50,
      description:
      "Vada pav, alternatively spelt wada pao, ( listen) is a vegetarian fast food dish native to the state of Maharashtra. The dish consists of a deep fried potato dumpling placed inside a bread bun (pav) sliced almost in half through the middle. It is generally accompanied with one or more chutneys and a green chili pepper.",
    ),
    FoodItem(
      name: "Misal",
      id: "103",
      images: [
        "assets/images/misal.jpg",
        //"assets/images/misal2.jpg",
        "assets/images/misal3.jpg",
        "assets/images/misal4.jpg"
      ],
      price: 100,
      description:
      "Misal (Marathi: मिसळ [Misal], meaning mixture), is a very popular spicy dish in the Western Indian state of Maharashtra. The dish is mostly eaten for breakfast or as a midday snack or sometimes as a one-dish meal, often as part of misal pav.",
    ),

  ];
}
